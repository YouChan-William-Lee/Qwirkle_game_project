# apt-assignment-2-ideabullet
Advanced Programming Techniques Assignment 2
